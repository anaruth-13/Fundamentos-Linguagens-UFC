## 10. Gerenciamento de Memória

(Comparativo Python x C...)