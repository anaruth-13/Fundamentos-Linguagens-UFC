## 2. Ambientes de Programação

(Compilador, Interpretador, Máquina Virtual...)