## 13. Linguagens para Scripts e Web

(Script de análise de transações bancárias em Python...)