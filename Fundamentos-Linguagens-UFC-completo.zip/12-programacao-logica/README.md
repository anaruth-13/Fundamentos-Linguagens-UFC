## 12. Programação Lógica

(Árvore genealógica em Prolog...)