## 4. Tipos de Dados

(Comparação Python, C e JavaScript...)