## 11. Programação Funcional

(Soma com recursão e funções de alta ordem...)