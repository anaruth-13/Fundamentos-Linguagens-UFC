## 5. Estruturas de Controle

(DataFrame fictício de funcionários...)