## 7. Implementação de Subprogramas

(Fatorial Recursivo e pilha de chamadas...)