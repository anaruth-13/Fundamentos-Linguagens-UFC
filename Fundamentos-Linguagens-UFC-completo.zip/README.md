# Fundamentos de Linguagens de Programação - UFC

**Universidade Federal do Ceará - Campus Crateús**  
**Curso de Sistemas de Informação**  
**Disciplina:** CRT0031 - Linguagens de Programação  
**Professor:** Bruno de Castro Honorato Silva  
**Semestre:** 2025.1  

---

## Estrutura do Repositório

- [01 - Introdução](01-introducao/README.md)  
- [02 - Ambientes de Programação](02-ambientes/README.md)  
- [03 - Sintaxe e Semântica](03-sintaxe-semantica/README.md)  
- [04 - Tipos de Dados](04-tipos-de-dados/README.md)  
- [05 - Estruturas de Controle](05-estruturas-de-controle/README.md)  
- [06 - Subprogramas](06-subprogramas/README.md)  
- [07 - Implementação de Subprogramas](07-implementacao-subprogramas/README.md)  
- [08 - Programação Orientada a Objetos](08-orientacao-objetos/README.md)  
- [09 - Concorrência](09-concorrencia/README.md)  
- [10 - Gerenciamento de Memória](10-gerenciamento-memoria/README.md)  
- [11 - Programação Funcional](11-programacao-funcional/README.md)  
- [12 - Programação Lógica](12-programacao-logica/README.md)  
- [13 - Linguagens para Scripts e Web](13-linguagens-scripts-web/README.md)  
- [14 - Tendências em Linguagens](14-tendencias/README.md)  

---
> Trabalho final da disciplina **Fundamentos de Linguagens de Programação**.
